<?php
$secret_key = 'sk_test_51UIMEcH9ALVxLaYkVzuVKVvGdF1tP6eXaXpFf6MIn8M4zhLYD1NNu42lKNCkhqqypcQOVIr4Hav9lSdvgO5jpjab001Zuy0ZsK';
$GOOGLE_CLIENT_ID =  '203220989350-eplf7vi0p29hc1an46uktm0a0qmc7mbk.apps.googleusercontent.com'; 


// return [
//     'client_id' => getenv('GOOGLE_CLIENT_ID') ?: '203220989350-eplf7vi0p29hc1an46uktm0a0qmc7mbk.apps.googleusercontent.com',
// ];