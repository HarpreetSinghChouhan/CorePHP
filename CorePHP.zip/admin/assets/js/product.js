
$(document).ready(function () {
    let table = null;
     const Toast = swal.mixin({
      toast: true,
      position: "top-end",  
      showConfirmButton: false,
      timer: 3000, 
      timerProgressBar: true,
      didOpen: (toast) =>{
        toast.onmouseenter  = swal.stopTimer;
        toast.onmouseleave = swal.resumeTimer;
      }
    });
    const esc = (s) => $("<div>").text(s ?? "").html();

    if ($("#product_datatable").length) {
        initProductTable();
    }

    function initProductTable() {
        table = $("#product_datatable").DataTable({
            ajax: {
                url: "/CorePHP/admin/backend/Product/GetProduct.php",
                dataSrc: function (json) {
                    return Array.isArray(json) ? json : (json.data || []);
                }
            },
            pageLength: 10,
            lengthMenu: [5, 10, 25, 50],
            order: [[2, "asc"]],
            columns: [
                { data: null, orderable: false, searchable: false,
                  render: (d, t, r, meta) => meta.row + 1 },
                { data: "image", orderable: false, searchable: false,
                  render: (d, t, r) =>
                    `<img src="${esc(d)}" alt="${esc(r.name)}" class="img-feild-table">` },
                { data: "name", className: "product-name", render: (d) => esc(d) },
                { data: "sku", render: (d) => esc(d) },
                { data: "price", render: (d) => esc(d) },
                { data: "category_name", render: (d) => esc(d) },
                { data: "description",
                  render: (d) => {
                      d = d ?? "";
                      return esc(d.length > 40 ? d.slice(0, 40) + "..." : d);
                  } },
                { data: "stock_quantity" },
                {data:"stock",
                     render: (d) => {
                           if (d === "In Stock") {
                              return `<span style="color: green; font-weight: 600;">${esc(d)}</span>`;
                               } else if (d === "Out of Stock") {
                             return `<span style="color: red; font-weight: 600;">${esc(d)}</span>`;
                                   }
                        return esc(d);
                     }
                  },
                { data: null, orderable: false, searchable: false, className: "action-cell",
                  render: () => `
                    <button type="button" class="btn-icon edit-link-btn edit-user" title="Edit">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                    <button type="button" class="btn-icon delete-user" title="Delete">
                        <i class="fa-solid fa-trash"></i>
                    </button>` }
            ],
            createdRow: function (row, p) {
                $(row).attr({
                    "data-id": p.id,
                    "data-name": p.name,
                    "data-price": p.price,
                    "data-sku": p.sku,
                    "data-category-name": p.category_name,
                    "data-description": p.description,
                    "data-image": p.image,
                    "data-stock_quantity": p.stock_quantity
                });
            }
        });

        table.on("draw.dt", function () {
            let start = table.page.info().start;
            table.column(0, { search: "applied", order: "applied", page: "current" })
                 .nodes()
                 .each((cell, i) => { cell.innerHTML = start + i + 1; });
        });
    }

 $("#EditProductForm").on("submit", function (e) {
        e.preventDefault();
        const ProductSkuPattern = /^\d{3}[a-zA-Z]{3,4}$/;
        $(".ProductNameError, .DescriptionError, .ProductSkuError, .PriceError, .ProductQuantityError, .ProductCategoryError, .ProductImageError").html("");
        const validationRules = [
            {
                input: $("#ProductName"),
                get value() {
                    return this.input.val() ? this.input.val().trim() : "";
                },
                errorEl: $(".ProductNameError"),
                isValid: function () {
                    return this.value.length >= 3;
                },
                get message() {
                    return this.value === ""
                        ? "Product Name is required."
                        : "Product Name must be at least 3 characters.";
                }
            },
            {
                input: $("#Description"),
                get value() {
                    return this.input.val() ? this.input.val().trim() : "";
                },
                errorEl: $(".DescriptionError"),
                isValid: function () {
                    return this.value.length >= 3;
                },
                get message() {
                    return this.value === ""
                        ? "Product Description is required."
                        : "Product Description must be at least 3 characters.";
                }
            },
            {
                input: $("#ProductSku"),
                get value() {
                    return this.input.val() ? this.input.val().trim() : "";
                },
                errorEl: $(".ProductSkuError"),
                isValid: function () {
                    return this.value !== "" && ProductSkuPattern.test(this.value);
                },
                get message() {
                    return this.value === ""
                        ? "Product SKU is required."
                        : "Product SKU must be 3 numbers followed by 7 to 10 letters.";
                }
            },
            {
                input: $("#Price"),
                get value() {
                    return this.input.val() ? this.input.val().trim() : "";
                },
                errorEl: $(".PriceError"),
                isValid: function () {
                    return this.value !== "" &&
                        !isNaN(this.value) &&
                        Number(this.value) >= 10 &&
                        Number(this.value) <= 100000;
                },
                get message() {
                    if (this.value === "") {
                        return "Price is required.";
                    }
                    return "Price must be minimum 10 and maximum 100000.";
                }
            },
            {
                input: $("#ProductQuantity"),
                get value() {
                    return this.input.val() ? this.input.val().trim() : "";
                },
                errorEl: $(".ProductQuantityError"),
                isValid: function () {
                    return this.value !== "" &&
                        !isNaN(this.value) &&
                        Number(this.value) >= 1 &&
                        Number.isInteger(Number(this.value));
                },
                get message() {
                    return this.value === ""
                        ? "Product Quantity is required."
                        : "Product Quantity must be a minimum of 1.";
                }
            },
            {
                input: $("#ProductCategory"),
                get value() {
                    return this.input.val() || "";
                },
                errorEl: $(".ProductCategoryError"),
                isValid: function () {
                    return this.value !== "";
                },
                message: "Product Category is required."
            },
            {
                input: $("#ProductImage"),
                get value() {
                    const files = this.input.prop("files");
                    return files && files.length > 0 ? files[0] : '';
                },
                errorEl: $(".ProductImageError"),
                isValid: function () {
                    const file = this.value;
                    if (file) {
                         const validTypes = ["image/png","image/jpeg","image/jpg","image/webp"];
                         return validTypes.includes(file.type) && file.size <= 2 * 1024 * 1024;
                        // return false;
                    }
                    else{
                        return true;
                    }
                },
                get message() {
                    if (this.value) {
                        return "Product Image must be PNG, JPG, JPEG or WEBP and maximum 2 MB.";
                    }   
                }
            }
        ];

        let isFormValid = true;
        let firstInvalidInput = null;

        $.each(validationRules, function (index, rule) {

            if (!rule.isValid()) {

                rule.errorEl.html(rule.message);

                isFormValid = false;

                if (!firstInvalidInput) {
                    firstInvalidInput = rule.input;
                }
            }
        });

        if (!isFormValid) {

            if (firstInvalidInput && firstInvalidInput.length) {
                firstInvalidInput.focus();
            }

            return false;
        }
       
        $.ajax({
        type: "POST",
                    url: "/CorePHP/admin/backend/Product/UpdateProduct.php",
                    data: new FormData(this),
                    processData: false,
                    contentType: false,

    success: function (response) {
        response = response.trim();

        if (response === "Exited") {
            Toast.fire({
                title: "Product Already Exists",
                icon: "warning"
            });
        } else if (response === "Success") {
            Toast.fire({
                title: "Product Updated Successfully",
                icon: "success"
            }).then(() => {
                window.location = "./index.php";
            });
        } else {
            Swal.fire({
                title: response,
                icon: "error"
            });
        }
       } 
      });
    });
 $("#AddProductForm").on("submit", function (e) {
        e.preventDefault();
        const ProductSkuPattern = /^\d{3}[a-zA-Z]{3,4}$/;
        $(".ProductNameError, .DescriptionError, .ProductSkuError, .PriceError, .ProductQuantityError, .ProductCategoryError, .ProductImageError").html("");
        const validationRules = [
            {
                input: $("#ProductName"),
                get value() {
                    return this.input.val() ? this.input.val().trim() : "";
                },
                errorEl: $(".ProductNameError"),
                isValid: function () {
                    return this.value.length >= 3;
                },
                get message() {
                    return this.value === ""
                        ? "Product Name is required."
                        : "Product Name must be at least 3 characters.";
                }
            },
            {
                input: $("#Description"),
                get value() {
                    return this.input.val() ? this.input.val().trim() : "";
                },
                errorEl: $(".DescriptionError"),
                isValid: function () {
                    return this.value.length >= 3;
                },
                get message() {
                    return this.value === ""
                        ? "Product Description is required."
                        : "Product Description must be at least 3 characters.";
                }
            },
            {
                input: $("#ProductSku"),
                get value() {
                    return this.input.val() ? this.input.val().trim() : "";
                },
                errorEl: $(".ProductSkuError"),
                isValid: function () {
                    return this.value !== "" && ProductSkuPattern.test(this.value);
                },
                get message() {
                    return this.value === ""
                        ? "Product SKU is required."
                        : "Product SKU must be 3 numbers followed by 7 to 10 letters.";
                }
            },
            {
                input: $("#Price"),
                get value() {
                    return this.input.val() ? this.input.val().trim() : "";
                },
                errorEl: $(".PriceError"),
                isValid: function () {
                    return this.value !== "" &&
                        !isNaN(this.value) &&
                        Number(this.value) >= 10 &&
                        Number(this.value) <= 100000;
                },
                get message() {
                    if (this.value === "") {
                        return "Price is required.";
                    }
                    return "Price must be minimum 10 and maximum 100000.";
                }
            },
            {
                input: $("#ProductQuantity"),
                get value() {
                    return this.input.val() ? this.input.val().trim() : "";
                },
                errorEl: $(".ProductQuantityError"),
                isValid: function () {
                    return this.value !== "" &&
                        !isNaN(this.value) &&
                        Number(this.value) >= 1 &&
                        Number.isInteger(Number(this.value));
                },
                get message() {
                    return this.value === ""
                        ? "Product Quantity is required."
                        : "Product Quantity must be a minimum of 1.";
                }
            },
            {
                input: $("#ProductCategory"),
                get value() {
                    return this.input.val() || "";
                },
                errorEl: $(".ProductCategoryError"),
                isValid: function () {
                    return this.value !== "";
                },
                message: "Product Category is required."
            },
            {
                input: $("#ProductImage"),
                get value() {
                    const files = this.input.prop("files");
                    return files && files.length > 0 ? files[0] : null;
                },
                errorEl: $(".ProductImageError"),
                isValid: function () {
                    const file = this.value;

                    if (!file) {
                        return false;
                    }
                    const validTypes = ["image/png","image/jpeg","image/jpg","image/webp"];

                    return validTypes.includes(file.type) &&
                        file.size <= 2 * 1024 * 1024;
                },
                get message() {
                    if (!this.value) {
                        return "Product Image is required.";
                    }

                    return "Product Image must be PNG, JPG, JPEG or WEBP and maximum 2 MB.";
                }
            }
        ];

        let isFormValid = true;
        let firstInvalidInput = null;

        $.each(validationRules, function (index, rule) {

            if (!rule.isValid()) {

                rule.errorEl.html(rule.message);

                isFormValid = false;

                if (!firstInvalidInput) {
                    firstInvalidInput = rule.input;
                }
            }
        });

        if (!isFormValid) {

            if (firstInvalidInput && firstInvalidInput.length) {
                firstInvalidInput.focus();
            }

            return false;
        }
       
        $.ajax({
        type: "POST",
                    url: "/CorePHP/admin/backend/Product/CreateProduct.php",
                    data: new FormData(this),
                    processData: false,
                    contentType: false,

    success: function (response) {
        response = response.trim();

        if (response === "Exited") {
            Toast.fire({
                title: "Product Already Exists",
                icon: "warning"
            });
        } else if (response === "Success") {
            Toast.fire({
                title: "Product Created Successfully",
                icon: "success"
            }).then(() => {
                window.location = "./index.php";
            });
        } else {
            Swal.fire({
                title: response,
                icon: "error"
            });
        }
    }
});
    });
    $(document).on("click", ".delete-user", function () {

        let row = $(this).closest("tr");
        let id = row.data("id");
        let name = row.find(".product-name").text().trim();
            swal.fire({
                 'title':'Are you sure?',
                'text':`You Want To Delete ${name}`,
                'icon':'warning',
                'showCancelButton':true,
                'cancelButtonColor':'Green',
                'confirmButtonColor':'Red',
                'confirmButtonText':'Yes, Delete it',
            }).then((result)=>{
                if(result.isConfirmed){
                    $.ajax({
                        url: "/CorePHP/admin/backend/Product/DeleteProduct.php",
                        type: "POST",
                            data: {
                            id: id
                             },
                        success: function (response) {

                            if (response.trim() === "success") {
                             swal.fire({
                                'title':'Product are Deleted',
                                'icon':'success'
                             });

                             row.fadeOut(500, function () {
                             $(this).remove();
                           });
                            } else {
                            swal.fire({
                                'title':`${response}`,
                                 'icon':'warning'
                            });
                            }
                        },

                    error: function () {
                      swal.fire({
                        'title':'Something Are Wrong ',
                        'icon':'warning'
                      })
                }
                    });
                }
            })

    });

    const IMPORT_URL = '/CorePHP/admin/backend/product/importproducts.php';

    const $dialog = $(`
        <dialog id="importDialog">
            <form id="importForm" enctype="multipart/form-data">
                <div class="import-dialog-box">
                    <h3>Import Products</h3>
                    <p>Select CSV file And Select Zip File For Image uplaod</p>
                    <input type="file" name="csv_file" id="csvFile" title="select csv file" accept=".csv" required>
                    <input type="file" name="images_zip" id="zipFile" title="select zip file" accept=".zip">
                    <div class="import-progress" id="importProgress">
                        <div class="import-progress-bar" id="importProgressBar"></div>
                    </div>
                    <div id="importStatus" class="import-status"></div>
                    <div id="importMessage" class="import-message"></div>
                    <div class="import-dialog-actions">
                        <button type="button" class="btn" id="importCloseBtn">Close</button>
                        <button type="submit" class="btn" id="importSubmitBtn">Upload</button>
                    </div>
                </div>
            </form>
        </dialog>
    `);
    $('body').append($dialog);

    const dialogEl = $dialog[0];
    const $form = $('#importForm');
    const $msg = $('#importMessage');
    const $status = $('#importStatus');
    const $progress = $('#importProgress');
    const $bar = $('#importProgressBar');
    const $submitBtn = $('#importSubmitBtn');
    const $closeBtn = $('#importCloseBtn');

    function resetDialog() {
        $form[0].reset();
        $msg.text('').removeClass('success error');
        $status.text('');
        $progress.hide().removeClass('processing');
        $bar.css('width', '0%');
        $submitBtn.prop('disabled', false).text('Upload');
        $closeBtn.prop('disabled', false);
    }

    $(document).on('click', '.import-csv-btn', function () {
        resetDialog();
        dialogEl.showModal();
    });

    $(document).on('click', '#importCloseBtn', function () {
        dialogEl.close();
    });

    $dialog.on('click', function (e) {
        if (e.target === dialogEl && !$closeBtn.prop('disabled')) dialogEl.close();
    });

    $dialog.on('cancel', function (e) {
        if ($closeBtn.prop('disabled')) e.preventDefault();
    });

    $form.on('submit', function (e) {
        e.preventDefault();
       
        const file = $('#csvFile')[0].files[0];

        if (!file) {
            $msg.text('Please Select Image').removeClass('success').addClass('error');
            return;
        }

        if (!file.name.toLowerCase().endsWith('.csv')) {
            $msg.text('Only .csv file allowed hai.').removeClass('success').addClass('error');
            return;
        }
        const zip = $('#zipFile')[0].files[0];
            if (zip && !zip.name.toLowerCase().endsWith('.zip')) {
                $msg.text('Only .zip file allowed.').removeClass('success').addClass('error');
                return;
            }

        const formData = new FormData(this);

        $.ajax({
            url: IMPORT_URL,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            xhr: function () {
                const xhr = $.ajaxSettings.xhr();
                xhr.upload.addEventListener('progress', function (e) {
                    if (e.lengthComputable) {
                        const percent = Math.round((e.loaded / e.total) * 100);
                        $bar.css('width', percent + '%');
                        $status.text('Uploading... ' + percent + '%');
                        if (percent === 100) {
                            $progress.addClass('processing');
                            $status.text('Processing... products import');
                        }
                    }
                });
                return xhr;
            },
            beforeSend: function () {
                $submitBtn.prop('disabled', true).text('Please wait...');
                $closeBtn.prop('disabled', true);
                $msg.text('').removeClass('success error');
                $bar.css('width', '0%');
                $progress.show().removeClass('processing');
                $status.text('Uploading... 0%');
            },
            success: function (res) {
                $progress.removeClass('processing');
                $bar.css('width', '100%');
                $closeBtn.prop('disabled', false);

                if (res.success) {
                    $status.text('Done');
                    $msg.text(res.message).removeClass('error').addClass('success');

                    if ($.fn.DataTable && $.fn.DataTable.isDataTable('#product_datatable')) {
                        $('#product_datatable').DataTable().ajax.reload(null, false);
                    }

                    setTimeout(function () { dialogEl.close(); }, 9000);
                } else {
                    $status.text('');
                    $progress.hide();
                    $msg.text(res.message || 'Import failed').removeClass('success').addClass('error');
                    $submitBtn.prop('disabled', false).text('Upload');
                }
            },
            error: function (xhr) {
                console.log(xhr.responseText);
                $status.text('');
                $progress.hide().removeClass('processing');
                $closeBtn.prop('disabled', false);
                $msg.text('Server error, try again.').removeClass('success').addClass('error');
                $submitBtn.prop('disabled', false).text('Upload');
            }
        });
    });
});