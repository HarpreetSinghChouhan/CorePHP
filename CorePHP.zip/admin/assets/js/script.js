$(document).ready(function () {
     
//     let params = new URLSearchParams(window.location.href);
//   console.log(params);  
    
    $('.create-link-btn').on("click",function(){
        window.location.href = "./create.php";
    });
    $(document).on("click",".view-link-btn",function(){
        console.log("Hello Working ");
        let row = $(this).closest("tr");
        let id = row.data("id");
        window.location.href = `./view.php?id=${id}`;
    });
    $('.btn-back').on("click",function(){
        window.location.href = "./index.php";
    })
    // $(".edit-link-btn").on("click",function(){
    //     window.location.href = "./edit.php";
    // })
     $(document).on("click",'.edit-link-btn',function(){
                let row = $(this).closest("tr");
        let id = row.data("id");

        window.location = `./edit.php?id=${id}`;

    //   window.location.href = "./edit.php";
 })
 $(document).on("click",".user-link-btn",function(){
    window.location = "/CorePHP/admin/user/index.php";
 })
 $(document).on("click",".order-link-btn",function(){
    window.location = "/CorePHP/admin/order/index.php";
 })
 
   
});