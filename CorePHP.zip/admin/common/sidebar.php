<?php
function isActivePage($folder) {
    $currentUrl = $_SERVER['REQUEST_URI'];
    if ($folder === '') {
        return (rtrim($currentUrl, '/') === '/CorePHP/admin/index.php') ? 'active' : '';
    }
    return (strpos($currentUrl, '/admin/' . $folder . '/') !== false) ? 'active' : '';
}
$sbName = $_SESSION['user_name'] ?? 'Admin';
?>
<aside class="admin-sidebar">
    <a href="/CorePHP/admin/index.php" class="brand">Admin<span>Panel</span></a>

    <div class="sidebar-chip">
        <div class="chip-avatar"><?php echo strtoupper(substr($sbName, 0, 1)); ?></div>
        <div>
            <strong><?php echo htmlspecialchars($sbName); ?></strong>
            <small>Administrator</small>
        </div>
    </div>

    <ul>
        <li><a href="/CorePHP/admin/index.php" class="<?php echo isActivePage(''); ?>">
            <span class="icon"><i class="fa-solid fa-house"></i></span> Dashboard
        </a></li>
        <li><a href="/CorePHP/admin/user/index.php" class="<?php echo isActivePage('user'); ?>">
            <span class="icon"><i class="fa-solid fa-users"></i></span> All Users
        </a></li>
        <li><a href="/CorePHP/admin/vendor/index.php" class="<?php echo isActivePage('vendor'); ?>">
            <span class="icon"><i class="fa-solid fa-users"></i></span> All Vendor
        </a></li>
        <li><a href="/CorePHP/admin/product/index.php" class="<?php echo isActivePage('product'); ?>">
            <span class="icon"><i class="fa-solid fa-box"></i></span> Product
        </a></li>
        <li><a href="/CorePHP/admin/category/index.php" class="<?php echo isActivePage('category'); ?>">
            <span class="icon"><i class="fa-solid fa-layer-group"></i></span> Category
        </a></li>
        <li><a href="/CorePHP/admin/order/index.php" class="<?php echo isActivePage('order'); ?>">
            <span class="icon"><i class="fa-solid fa-clipboard-list"></i></span> Orders
        </a></li>
        <li><a href="/CorePHP/admin/cart/index.php" class="<?php echo isActivePage('cart'); ?>">
            <span class="icon"><i class="fa-solid fa-cart-shopping"></i></span> Cart
        </a></li>
        <li><a href="/CorePHP/admin/wishlist/index.php" class="<?php echo isActivePage('wishlist'); ?>">
            <span class="icon"><i class="fa-solid fa-heart"></i></span> Wishlist
        </a></li>
        <li><a href="/CorePHP/auth/logout.php">
            <span class="icon"><i class="fa-solid fa-right-from-bracket"></i></span> Logout
        </a></li>
    </ul>

    <div class="sidebar-footer">&copy; <?php echo date('Y'); ?> Admin</div>
</aside>