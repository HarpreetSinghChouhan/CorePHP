<?php
require_once __DIR__ . '/../common/header.php';

require_once __DIR__ . '/../common/sidebar.php';
?>

<div class="admin-main">
    <script src="../assets/js/product.js"; defer ></script>
    <?php require_once __DIR__ . '/../common/navbar.php'; ?>

    <div class="admin-content">
        <div class="panel">
          <div class="table-header" >   
        <h1 class="center"> Product List</h1>   <div>   <button class="btn import-csv-btn import-btn vr-btn" > Import product</button>   <button class="btn create-link-btn"  >Add New Product</button>  </div>
            </div>
            <table id="product_datatable" >
                <thead>
                    <tr><th>Serial No</th><th>Image</th><th>Name</th><th>Sku</th><th>Price</th><th>Category Name</th><th>Product Description</th><th>Quantity</th> <th>Stock</th><th>Action</th></tr>
                </thead>
                <tbody class="product-tbody" >
                </tbody>
            </table>
        </div>

       
    </div>
<?php require_once __DIR__ . '/../common/footer.php'; ?>